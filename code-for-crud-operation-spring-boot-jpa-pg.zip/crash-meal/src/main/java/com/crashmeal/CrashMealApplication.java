package com.crashmeal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrashMealApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrashMealApplication.class, args);
	}
}

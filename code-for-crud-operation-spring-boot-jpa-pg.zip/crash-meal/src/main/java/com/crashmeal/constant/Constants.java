package com.crashmeal.constant;

public class Constants {
	public static final Integer FIELD_NAME_LENGTH = 150;
	public static final Integer FIELD_DESC_LENGTH = 250;
	
	public static final String FIELD_NAME_NULL_MSG = "Field 'Name' can not be null";
	public static final String FIELD_NAME_EMPTY_MSG = "Field 'Name' can not be empty";
	public static final String FIELD_NAME_LENGTH_MSG = "Length of the field Name can not be more than 150";
	
	public static final String FIELD_DESC_NULL_MSG = "Field 'Description' can not be null";
	public static final String FIELD_DESC_EMPTY_MSG = "Field 'Description' can not be empty";
	public static final String FIELD_DESC_LENGTH_MSG = "Length of the field 'Description' can not be more than 250";
	
	public static final String PROD_CAT_NOT_FOUND_MSG = "Product Category Not Found";
	public static final String PROD_SUB_CAT_NOT_FOUND_MSG = "Product Sub Category Not Found";
	
	public static final String JSON_MAPPING_EXCEPTION_MSG = "JSON Mapping Exception";
}

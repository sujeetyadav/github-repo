package com.crashmeal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.crashmeal.model.ProductCategoryRequest;
import com.crashmeal.service.ProductCategoryService;
import com.crashmeal.service.ValidationService;

@RestController
public class ProductCategoryController {
	@Autowired
	private ProductCategoryService productCategoryService;

	@Autowired
	private ValidationService validationService;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductCategoryController.class);

	@PostMapping(value = "/product/category/create")
	public ResponseEntity<?> createProductCategory(@RequestBody ProductCategoryRequest productCategoryRequest) {
		LOGGER.info("productCategory " + productCategoryRequest);
		validationService.validateProductCategory(productCategoryRequest);
		return productCategoryService.createProductCategory(productCategoryRequest);
	}
}

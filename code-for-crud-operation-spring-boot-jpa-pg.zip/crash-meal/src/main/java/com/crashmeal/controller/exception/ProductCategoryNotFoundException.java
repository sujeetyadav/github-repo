package com.crashmeal.controller.exception;

public class ProductCategoryNotFoundException extends Exception {
	public ProductCategoryNotFoundException(String s) {
		super(s);
	}
}

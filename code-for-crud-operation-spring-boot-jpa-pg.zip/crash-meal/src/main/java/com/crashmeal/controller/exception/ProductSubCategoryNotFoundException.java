package com.crashmeal.controller.exception;

public class ProductSubCategoryNotFoundException extends Exception {
	public ProductSubCategoryNotFoundException(String s) {
		super(s);
	}
}

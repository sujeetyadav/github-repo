package com.crashmeal.controller.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.crashmeal.constant.Constants;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;

@RestControllerAdvice
public class RestControllerExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(RestControllerExceptionHandler.class);

	@ExceptionHandler(MismatchedInputException.class)
	public ResponseEntity<String> handleIllegalArgException(MismatchedInputException exception) {
		String message = exception.getMessage();
		String messageSplit[] = message.split("\n");
		String responseMessage;
		if (messageSplit.length != 0) {
			responseMessage = messageSplit[0];
		} else {
			responseMessage = Constants.JSON_MAPPING_EXCEPTION_MSG;
		}
		LOGGER.error(exception.getMessage());
		return new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ProductCategoryNotFoundException.class)
	public ResponseEntity<String> handleProductCategoryNotFoundException(ProductCategoryNotFoundException exception) {
		LOGGER.error(exception.getMessage());
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ProductSubCategoryNotFoundException.class)
	public ResponseEntity<String> handleProductSubCategoryNotFoundException(
			ProductSubCategoryNotFoundException exception) {
		LOGGER.error(exception.getMessage());
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException exception) {
		LOGGER.error(exception.getMessage());
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleInternalServerError(Exception exception) {
		LOGGER.error(exception.getMessage());
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

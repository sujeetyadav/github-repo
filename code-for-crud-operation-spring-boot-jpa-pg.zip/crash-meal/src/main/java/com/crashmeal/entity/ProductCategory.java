package com.crashmeal.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "product_category")
public class ProductCategory {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "cat_id")
	private Integer id;

	@Column(name = "cat_name")
	private String catName;

	@Column(name = "cat_desc")
	private String catDesc;

	@OneToMany(mappedBy="productCategory")
	private List<ProductSubCategory> productSubCategoryList;

	@OneToMany(mappedBy="productCategory")
	private List<Product> product;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}

	public String getCatDesc() {
		return catDesc;
	}

	public void setCatDesc(String catDesc) {
		this.catDesc = catDesc;
	}

	public List<ProductSubCategory> getProductSubCategoryList() {
		return productSubCategoryList;
	}

	public void setProductSubCategoryList(List<ProductSubCategory> productSubCategoryList) {
		this.productSubCategoryList = productSubCategoryList;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductCategory [id=" + id + ", catName=" + catName + ", catDesc=" + catDesc + "]";
	}

}

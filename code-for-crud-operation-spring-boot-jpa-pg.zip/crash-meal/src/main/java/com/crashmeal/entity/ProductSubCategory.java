package com.crashmeal.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "product_sub_category")
public class ProductSubCategory {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "sub_cat_id")
	private Integer id;

	@Column(name = "sub_cat_name")
	private String subCatName;

	@Column(name = "sub_cat_desc")
	private String subCatDesc;

	@ManyToOne
	@JoinColumn(name="cat_id")
	private ProductCategory productCategory;

	@OneToMany(mappedBy="productSubCategory")
	private List<Product> product;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSubCatName() {
		return subCatName;
	}

	public void setSubCatName(String subCatName) {
		this.subCatName = subCatName;
	}

	public String getSubCatDesc() {
		return subCatDesc;
	}

	public void setSubCatDesc(String subCatDesc) {
		this.subCatDesc = subCatDesc;
	}

	public ProductCategory getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductSubCategory [id=" + id + ", subCatName=" + subCatName + ", subCatDesc=" + subCatDesc
				+ ", productCategory=" + productCategory + "]";
	}

}

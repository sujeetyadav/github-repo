package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductCategoryRequest {
	@JsonCreator
	public ProductCategoryRequest(@JsonProperty(value = "name", required = true) String prodCatName,
			@JsonProperty(value = "desc", required = true) String prodCatdesc) {
		this.prodCatName = prodCatName;
		this.prodCatdesc = prodCatdesc;
	}

	private String prodCatName;

	private String prodCatdesc;

	public String getProdCatName() {
		return prodCatName;
	}

	public void setProdCatName(String prodCatName) {
		this.prodCatName = prodCatName;
	}

	public String getProdCatdesc() {
		return prodCatdesc;
	}

	public void setProdCatdesc(String prodCatdesc) {
		this.prodCatdesc = prodCatdesc;
	}

	@Override
	public String toString() {
		return "ProductCategory [prodCatName=" + prodCatName + ", prodCatdesc=" + prodCatdesc + "]";
	}
}

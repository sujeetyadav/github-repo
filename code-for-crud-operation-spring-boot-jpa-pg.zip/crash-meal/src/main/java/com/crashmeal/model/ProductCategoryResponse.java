package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductCategoryResponse {
	@JsonProperty(value = "productCategoryId")
	private Integer productCategoryId;

	public Integer getProductCategoryId() {
		return productCategoryId;
	}

	public void setProductCategoryId(Integer productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
}

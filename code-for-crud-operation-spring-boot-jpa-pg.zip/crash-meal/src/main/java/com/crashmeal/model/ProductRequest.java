package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductRequest {

	@JsonCreator
	public ProductRequest(@JsonProperty(value = "categoryId", required = true) Integer categoryId,
			@JsonProperty(value = "subcategoryId", required = true) Integer subcategoryId,
			@JsonProperty(value = "name", required = true) String prodName,
			@JsonProperty(value = "desc", required = false, defaultValue = "true") Boolean eligibility) {
		this.categoryId = categoryId;
		this.subcategoryId = subcategoryId;
		this.prodName = prodName;
		this.eligibility = eligibility;
	}

	private Integer categoryId;

	private Integer subcategoryId;

	private String prodName;

	private Boolean eligibility;

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(Integer subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Boolean getEligibility() {
		return eligibility;
	}

	public void setEligibility(Boolean eligibility) {
		this.eligibility = eligibility;
	}

	@Override
	public String toString() {
		return "Product [categoryId=" + categoryId + ", subcategoryId=" + subcategoryId + ", prodName=" + prodName
				+ ", eligibility=" + eligibility + "]";
	}
}

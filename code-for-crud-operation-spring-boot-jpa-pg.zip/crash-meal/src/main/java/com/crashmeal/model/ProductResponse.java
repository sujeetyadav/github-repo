package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductResponse {
	@JsonProperty(value = "productId")
	private Integer productId;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

}

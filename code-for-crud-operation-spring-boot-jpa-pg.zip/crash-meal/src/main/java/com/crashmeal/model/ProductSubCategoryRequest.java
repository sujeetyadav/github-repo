package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductSubCategoryRequest {

	@JsonCreator
	public ProductSubCategoryRequest(@JsonProperty(value = "categoryId", required = true) Integer categoryId,
			@JsonProperty(value = "name", required = true) String prodSubCatName,
			@JsonProperty(value = "desc", required = true) String prodSubCatDesc) {
		this.categoryId = categoryId;
		this.prodSubCatName = prodSubCatName;
		this.prodSubCatDesc = prodSubCatDesc;

	}

	private Integer categoryId;

	private String prodSubCatName;

	private String prodSubCatDesc;

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getProdSubCatName() {
		return prodSubCatName;
	}

	public void setProdSubCatName(String prodSubCatName) {
		this.prodSubCatName = prodSubCatName;
	}

	public String getProdSubCatDesc() {
		return prodSubCatDesc;
	}

	public void setProdSubCatDesc(String prodSubCatDesc) {
		this.prodSubCatDesc = prodSubCatDesc;
	}

	@Override
	public String toString() {
		return "ProductSubCategory [categoryId=" + categoryId + ", prodSubCatName=" + prodSubCatName
				+ ", prodSubCatDesc=" + prodSubCatDesc + "]";
	}
}

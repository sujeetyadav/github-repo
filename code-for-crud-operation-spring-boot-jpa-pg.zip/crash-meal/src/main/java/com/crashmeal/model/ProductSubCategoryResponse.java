package com.crashmeal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductSubCategoryResponse {
	@JsonProperty(value = "productSubCategoryId")
	private Integer productSubCategoryId;

	public Integer getProductSubCategoryId() {
		return productSubCategoryId;
	}

	public void setProductSubCategoryId(Integer productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}

}

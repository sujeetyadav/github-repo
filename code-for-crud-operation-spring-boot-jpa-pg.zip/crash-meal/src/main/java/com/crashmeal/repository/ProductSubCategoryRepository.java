package com.crashmeal.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.crashmeal.entity.ProductSubCategory;

@Repository
public interface ProductSubCategoryRepository extends CrudRepository<ProductSubCategory, Integer> {
}

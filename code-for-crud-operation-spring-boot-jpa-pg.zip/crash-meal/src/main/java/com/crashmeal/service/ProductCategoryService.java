package com.crashmeal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crashmeal.entity.ProductCategory;
import com.crashmeal.model.ProductCategoryRequest;
import com.crashmeal.model.ProductCategoryResponse;
import com.crashmeal.repository.ProductCategoryRepository;

@Service
public class ProductCategoryService {

	@Autowired
	private ProductCategoryRepository productCategoryRepository;

	public ResponseEntity<?> createProductCategory(ProductCategoryRequest productCategoryRequest) {
		ProductCategory productCategory = getProductCategoryEntity(productCategoryRequest);
		productCategory = productCategoryRepository.save(productCategory);

		ProductCategoryResponse productCategoryResponse = new ProductCategoryResponse();
		productCategoryResponse.setProductCategoryId(productCategory.getId());

		return new ResponseEntity<ProductCategoryResponse>(productCategoryResponse, HttpStatus.CREATED);
	}

	private ProductCategory getProductCategoryEntity(ProductCategoryRequest productCategoryRequest) {
		ProductCategory productCateogy = new ProductCategory();
		productCateogy.setCatName(productCategoryRequest.getProdCatName());
		productCateogy.setCatDesc(productCategoryRequest.getProdCatdesc());
		return productCateogy;
	}
}

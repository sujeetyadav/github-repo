package com.crashmeal.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crashmeal.constant.Constants;
import com.crashmeal.controller.exception.ProductCategoryNotFoundException;
import com.crashmeal.controller.exception.ProductSubCategoryNotFoundException;
import com.crashmeal.entity.Product;
import com.crashmeal.entity.ProductCategory;
import com.crashmeal.entity.ProductSubCategory;
import com.crashmeal.model.ProductRequest;
import com.crashmeal.model.ProductResponse;
import com.crashmeal.repository.ProductCategoryRepository;
import com.crashmeal.repository.ProductRepository;
import com.crashmeal.repository.ProductSubCategoryRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProductCategoryRepository productCategoryRepository;

	@Autowired
	private ProductSubCategoryRepository productSubCategoryRepository;

	public ResponseEntity<?> createProduct(ProductRequest productRequest)
			throws ProductCategoryNotFoundException, ProductSubCategoryNotFoundException {
		Product product = getProductEntity(productRequest);
		product = productRepository.save(product);

		ProductResponse productResponse = new ProductResponse();
		productResponse.setProductId(product.getId());

		return new ResponseEntity<ProductResponse>(productResponse, HttpStatus.CREATED);
	}

	private Product getProductEntity(ProductRequest productRequest)
			throws ProductCategoryNotFoundException, ProductSubCategoryNotFoundException {
		Product product = new Product();

		Boolean eligibility = (productRequest.getEligibility() == null) ? true : productRequest.getEligibility();
		product.setEligibility(eligibility);
		product.setProdName(productRequest.getProdName());

		Optional<ProductCategory> productCategory = productCategoryRepository.findById(productRequest.getCategoryId());

		if (productCategory.isPresent()) {
			product.setProductCategory(productCategory.get());
		} else {
			throw new ProductCategoryNotFoundException(Constants.PROD_CAT_NOT_FOUND_MSG);
		}

		Optional<ProductSubCategory> productSubCategory = productSubCategoryRepository
				.findById(productRequest.getSubcategoryId());

		if (productSubCategory.isPresent()) {
			product.setProductSubCategory(productSubCategory.get());
		} else {
			throw new ProductSubCategoryNotFoundException(Constants.PROD_SUB_CAT_NOT_FOUND_MSG);
		}

		return product;
	}
}

package com.crashmeal.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crashmeal.constant.Constants;
import com.crashmeal.controller.exception.ProductCategoryNotFoundException;
import com.crashmeal.entity.ProductCategory;
import com.crashmeal.entity.ProductSubCategory;
import com.crashmeal.model.ProductSubCategoryRequest;
import com.crashmeal.model.ProductSubCategoryResponse;
import com.crashmeal.repository.ProductCategoryRepository;
import com.crashmeal.repository.ProductSubCategoryRepository;

@Service
public class ProductSubCategoryService {

	@Autowired
	private ProductSubCategoryRepository productSubCategoryRepository;

	@Autowired
	private ProductCategoryRepository productCategoryRepository;

	public ResponseEntity<?> createProductSubCategory(ProductSubCategoryRequest productSubCategoryRequest)
			throws ProductCategoryNotFoundException {
		ProductSubCategory productSubCategory = getProductSubCategoryEntity(productSubCategoryRequest);
		productSubCategory = productSubCategoryRepository.save(productSubCategory);

		ProductSubCategoryResponse productSubCategoryResponse = new ProductSubCategoryResponse();
		productSubCategoryResponse.setProductSubCategoryId(productSubCategory.getId());

		return new ResponseEntity<ProductSubCategoryResponse>(productSubCategoryResponse, HttpStatus.CREATED);
	}

	private ProductSubCategory getProductSubCategoryEntity(ProductSubCategoryRequest productSubCategoryRequest)
			throws ProductCategoryNotFoundException {
		ProductSubCategory productSubCateogy = new ProductSubCategory();
		productSubCateogy.setSubCatName(productSubCategoryRequest.getProdSubCatName());
		productSubCateogy.setSubCatDesc(productSubCategoryRequest.getProdSubCatDesc());
		Optional<ProductCategory> productCategory = productCategoryRepository
				.findById(productSubCategoryRequest.getCategoryId());
		if (productCategory.isPresent()) {
			productSubCateogy.setProductCategory(productCategory.get());
		} else {
			throw new ProductCategoryNotFoundException(Constants.PROD_CAT_NOT_FOUND_MSG);
		}

		return productSubCateogy;
	}
}

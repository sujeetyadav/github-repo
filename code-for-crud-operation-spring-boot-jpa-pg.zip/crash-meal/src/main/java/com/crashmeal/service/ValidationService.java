package com.crashmeal.service;

import org.springframework.stereotype.Service;

import com.crashmeal.constant.Constants;
import com.crashmeal.model.ProductCategoryRequest;
import com.crashmeal.model.ProductRequest;
import com.crashmeal.model.ProductSubCategoryRequest;

@Service
public class ValidationService {

	public void validateProductCategory(ProductCategoryRequest productCategoryRequest) {
		validateName(productCategoryRequest.getProdCatName());
		validateDescription(productCategoryRequest.getProdCatdesc());
	}

	public void validateProductSubCategory(ProductSubCategoryRequest productSubCategoryRequest) {
		validateName(productSubCategoryRequest.getProdSubCatName());
		validateDescription(productSubCategoryRequest.getProdSubCatDesc());
	}

	public void validateProduct(ProductRequest productRequest) {
		validateName(productRequest.getProdName());
	}

	private void validateName(String name) {
		if (name == null) {
			throw new IllegalArgumentException(Constants.FIELD_NAME_NULL_MSG);
		} else {
			if (name.isEmpty()) {
				throw new IllegalArgumentException(Constants.FIELD_NAME_EMPTY_MSG);
			} else {
				if (name.length() > Constants.FIELD_NAME_LENGTH) {
					throw new IllegalArgumentException(Constants.FIELD_NAME_LENGTH_MSG);
				}
			}
		}
	}

	private void validateDescription(String description) {
		if (description == null) {
			throw new IllegalArgumentException(Constants.FIELD_DESC_NULL_MSG);
		} else {
			if (description.isEmpty()) {
				throw new IllegalArgumentException(Constants.FIELD_DESC_EMPTY_MSG);
			} else {
				if (description.length() > Constants.FIELD_DESC_LENGTH) {
					throw new IllegalArgumentException(Constants.FIELD_DESC_LENGTH_MSG);
				}
			}
		}
	}

}

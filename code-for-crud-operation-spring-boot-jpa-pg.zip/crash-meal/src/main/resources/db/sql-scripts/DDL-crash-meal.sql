CREATE TABLE crash_meal.product_category (
  cat_id serial PRIMARY KEY,
  cat_name varchar,
  cat_desc varchar
);


CREATE TABLE crash_meal.product_sub_category (
  sub_cat_id serial PRIMARY KEY,
  sub_cat_name varchar,
  sub_cat_desc varchar,
  cat_id integer,
  CONSTRAINT fk_product_sub_category_product_category
  FOREIGN KEY (cat_id) REFERENCES crash_meal.product_category (cat_id)
);


CREATE TABLE crash_meal.product (
  prod_id serial PRIMARY KEY,
  prod_name varchar,
  eligibility boolean,
  cat_id integer,
  sub_cat_id integer,
  CONSTRAINT fk_product_product_category
  FOREIGN KEY (cat_id) REFERENCES crash_meal.product_category (cat_id),
  CONSTRAINT fk_product_product_sub_category
  FOREIGN KEY (sub_cat_id) REFERENCES crash_meal.product_sub_category (sub_cat_id)
);